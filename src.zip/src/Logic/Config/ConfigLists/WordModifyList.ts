import { LanguageInterface } from "../../Core/Modules/Language/Language.interface";

export const WordModifyList: LanguageInterface.TWordModifyList = {
	ERROR: { EN: [[10, 10]], RU: [[10, 10]] },
};
