import { LanguageInterface } from "Logic/Core/Modules/Language/Language.interface";

export const WordTransferList: LanguageInterface.TWordTransferList = {
	ERROR: { EN: [3], RU: [3] },
};
