interface Navigator {
	userLanguage: string;
	systemLanguage: string;
}
